package com.example.wirtualnaszafa.ui.collections;

public class CollectionsViewModel {
}
